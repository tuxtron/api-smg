This is the client profile for the client/server example where the client and server communications using HTTP. 
