### Rest Quickstart Profile

This profile runs the REST quickstart example
