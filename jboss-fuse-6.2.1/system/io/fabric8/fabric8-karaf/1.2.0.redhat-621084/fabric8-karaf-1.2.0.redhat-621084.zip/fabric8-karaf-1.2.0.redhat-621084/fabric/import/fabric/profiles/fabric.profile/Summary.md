This is the profile for Fabric server.
