default A-MQ broker without the legacy web console
