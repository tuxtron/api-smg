## Fabric DOSGi Consumer

This is the consumer, which uses the DOSGi service provided by the producer.

### Installing

Install this profile to a container.
And then install the producer to another container, to facailitate Distributed OSGi services.
