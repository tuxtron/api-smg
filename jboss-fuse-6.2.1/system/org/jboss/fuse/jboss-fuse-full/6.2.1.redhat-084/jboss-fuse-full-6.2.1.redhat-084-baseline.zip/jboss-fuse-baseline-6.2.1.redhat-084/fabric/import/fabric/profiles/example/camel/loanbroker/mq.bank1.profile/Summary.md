This is the bank1 profile for the loan broaker example
