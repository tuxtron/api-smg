Insight Metrics implemented with ElasticSearch
