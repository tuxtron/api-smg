## OpenShift

Fabric8 has been designed so that it can work both in very low hardware environments (1 to 3 JVMs is all thats required) all the way to scaling up to massive multi-hyrbid cloud environments. 

The main PaaS that fabric8's been designed to work well on is [OpenShift](https://www.openshift.com/).

### Getting Started

To spin up your own free instance of fabric8 (inside the JBoss Fuse distribution) please use the [JBoss Fuse Quickstart](https://openshift.redhat.com/app/console/application_type/quickstart!16634)

