This is the loan broker profile for the loan broaker example
