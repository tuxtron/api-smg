A profile which provides an ActiveMQConnectionFactory (JMS client) for connecting via JMS or Camel to an A-MQ broker running on localhost.

Typically this is used for working with local brokers on the same machine; or for when the [gateway profile](/fabric/profiles/gateway/default.profile) is used to proxy to the actual locations of the brokers.
