Test messages to send to the [camel-example-wiki profile](/fabric/profiles/example/camel/wiki.profile) when using the autotest profile.
