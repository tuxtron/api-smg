This folder contains the test messages for each Camel Context and Route.

There is a folder for each Camel Context ID, then for each Camel Context ID there is a folder for each Route ID containing the example messages to send to that route whenever the camel context reloads.
